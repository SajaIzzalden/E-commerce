/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecommercesystem;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner sc = new Scanner(System.in);
      // Create an electronic product
    ElectronicProduct electronicProduct = new ElectronicProduct(1, "Laptop", 12500.90f, "ASUS", 2);

    // Create a clothing product
    ClothingProduct clothingProduct = new ClothingProduct(2, "Jeans", 45.99f, "free size", "denim");

    // Create a book product
    BookProduct bookProduct = new BookProduct(3, "OOP", 39.99f, "O'Reilly", "X Publications");

    // Create a customer
    System.out.println("Welcome to the E-Commerce System!");
    System.out.print("Enter your customer ID: ");
    int customerId = sc.nextInt();
    System.out.print("Enter your name: ");
    String name = sc.next();
    System.out.print("Enter your address: ");
    String address = sc.next();
    Customer customer = new Customer(customerId, name, address);

    // Create a shopping cart for the customer
    System.out.print("How many products do you want to order? ");
    int nProducts = sc.nextInt();
Cart cart = new Cart(customer.getCustomerId(), nProducts);

    // Add products to the cart
    for (int i = 0; i < nProducts; i++) {
         System.out.println("Which product would you like to add? 1- Laptop 2- jeans 3- OOP");
        int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    cart.addProduct(i,electronicProduct );
                    break;
                case 2:
                    cart.addProduct(i,  clothingProduct);
                    break;
                case 3:
                    cart.addProduct(i, bookProduct);
                    break;
                default:
                    System.out.println("Invalid choice!");  
   } 
    }
     cart.calculatePrice();
 
     System.out.println("Your total is $" + cart.calculatePrice()+ ". Would you like to place the order? 1- Yes 2- No");
        int placeOrder = sc.nextInt();
        if (placeOrder == 1) {
          
            Order order = new Order(customer.getCustomerId(),1,cart.getProducts());
            System.out.println("Here's your order's summary:");
            order.printOrderInfo();
        } else {
            System.out.println("Order cancelled.");
        }

    }
    
}
