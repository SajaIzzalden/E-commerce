/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;

/**
 *
 * @author ASUS
 */
public class Cart {
    private int customerId;
    private int nProduct;
    private Product[] products;

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = Math.abs(customerId);
    }

    public int getnProduct() {
        return nProduct;
    }

    public void setnProduct(int nProduct) {
        this.nProduct = Math.abs(nProduct);
    }

      public Product[] getProducts() {
        return products;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public Cart(int customerId, int nProduct) {

        this.customerId = Math.abs(customerId); 
        this.nProduct = Math.abs(nProduct); 
        products = new Product[nProduct];
    }

    

    public void addProduct(int index, Product product) {
        products[index] = product;
    }
    
    public void removeProduct(int index){
       products[index]=null;
    }
 public float calculatePrice(){
    float totalPrice = 0;
    for (Product product : products) {
        if (product != null) {
            totalPrice += product.getPrice();
        }
    }
    return totalPrice;
}
     public void placeOrder() {
        System.out.println("Order placed successfully!");
    }

}


    
    
  
    

